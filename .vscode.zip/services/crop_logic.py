def recommend_crop(temp: float, humidity: float, soil: str) -> str:
    """
    🌱 Determine the best crop based on:
    - Temperature
    - Humidity
    - Soil type
    """

    # نحول soil لحروف صغيرة لتجنب المشاكل
    soil = soil.lower()

    # 🌽 Hot & dry
    if temp > 30 and humidity < 50:
        return "Corn 🌽"

    # 🌾 Cool & humid
    elif temp < 25 and humidity > 60:
        return "Rice 🌾"

    # 🧵 Clay soil
    elif soil == "clay":
        return "Cotton 🧵"

    # 🍉 Sandy soil
    elif soil == "sandy":
        return "Watermelon 🍉"

    # 🌾 Default
    else:
        return "Wheat 🌾"