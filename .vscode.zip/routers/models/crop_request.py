from sqlalchemy import Column, Integer, String, Float, DateTime
from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime
from sqlalchemy import Column, Integer, String, Float, DateTime
from datetime import datetime

from database import Base
class CropRequest(Base):
    __tablename__ = "crop_requests"

    id = Column(Integer, primary_key=True, index=True)
    city = Column(String, index=True)
    temperature = Column(Float)
    humidity = Column(Float)
    soil_type = Column(String)

    recommended_crop = Column(String, index=True)  # ⭐ مهم للتحليلات
    created_at = Column(DateTime, default=datetime.utcnow, index=True)  # ⭐ مهم للسرعة
