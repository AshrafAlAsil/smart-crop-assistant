from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from database import SessionLocal
from models.crop_request import CropRequest
from routers.city import get_db
from services.geocoding import get_coordinates
from services.crop_logic import recommend_crop

from schemas.crop import CropRequestSchema

router = APIRouter(prefix="/crop", tags=["Crop"])
@router.post("/crop-request")
def create_crop_request(
    data: CropRequestSchema,
    db: Session = Depends(get_db)
):
    lat, lon = get_coordinates(data.city)

    if lat is None:
        raise HTTPException(status_code=404, detail="City not found")

    recommended = recommend_crop(
        data.temperature,
        data.humidity,
        data.soil_type
    )

    crop = CropRequest(
        city=data.city,
        temperature=data.temperature,
        humidity=data.humidity,
        soil_type=data.soil_type,
        latitude=lat,
        longitude=lon,
        recommended_crop=recommended
    )

    db.add(crop)
    db.commit()
    db.refresh(crop)

    return {"status": "success", "recommended_crop": recommended}
